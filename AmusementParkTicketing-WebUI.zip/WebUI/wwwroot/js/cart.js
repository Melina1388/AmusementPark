// ==========================================================================
// cart.js
// مدیریت افزایش/کاهش تعداد بلیط در سبد خرید، محاسبه‌ی زنده‌ی مجموع هر ردیف
// و مجموع کل، و حذف انیمیشنی ردیف/گروه شهربازی وقتی تعداد به صفر برسد.
// ==========================================================================

document.addEventListener('DOMContentLoaded', function () {

    var checkoutBtn = document.getElementById('checkoutBtn');

    /** فرمت عدد با جداکننده‌ی هزارگان فارسی. */
    function formatNumber(value) {
        return Math.round(value).toLocaleString('fa-IR');
    }

    /** محاسبه‌ی مجدد مجموع کل بر اساس تمام ردیف‌های باقی‌مانده و به‌روزرسانی نوار پایین. */
    function recalculateGrandTotal() {
        var rows = document.querySelectorAll('[data-cart-row]');
        var grandTotal = 0;

        rows.forEach(function (row) {
            var unitPrice = parseFloat(row.getAttribute('data-unit-price'));
            var quantity = parseInt(row.getAttribute('data-quantity'), 10);
            grandTotal += unitPrice * quantity;
        });

        var grandTotalEl = document.querySelector('[data-grand-total]');
        if (grandTotalEl) {
            grandTotalEl.textContent = formatNumber(grandTotal);
        }
        if (checkoutBtn) {
            checkoutBtn.setAttribute('data-grand-total-amount', grandTotal);
            checkoutBtn.setAttribute('href', '/Payment?totalAmount=' + Math.round(grandTotal));
        }

        // اگر همه‌ی ردیف‌ها حذف شدند، نوار پایین هم مخفی شود.
        var totalBar = document.querySelector('.cart-total-bar');
        if (totalBar && rows.length === 0) {
            totalBar.style.display = 'none';
        }
    }

    /** حذف انیمیشنی یک ردیف؛ اگر گروه شهربازی خالی شد، خودِ گروه هم حذف می‌شود. */
    function removeRow(row) {
        row.classList.add('row-removing');
        row.addEventListener('transitionend', function handler() {
            row.removeEventListener('transitionend', handler);
            var parkGroup = row.closest('[data-park-group]');
            row.remove();

            if (parkGroup && parkGroup.querySelectorAll('[data-cart-row]').length === 0) {
                parkGroup.remove();
            }

            recalculateGrandTotal();

            // اگر سبد کاملاً خالی شد، پیام «سبد خالی» نمایش داده شود.
            if (document.querySelectorAll('[data-cart-row]').length === 0) {
                var cartWrap = document.querySelector('.cart-wrap');
                var emptyState = document.createElement('div');
                emptyState.className = 'cart-empty';
                emptyState.innerHTML = '<span class="big-emoji">🎈</span> سبد خریدت فعلاً خالیه!';
                cartWrap.appendChild(emptyState);
            }
        }, { once: true });
    }

    document.querySelectorAll('[data-cart-row]').forEach(function (row) {
        var qtyValueEl = row.querySelector('[data-qty-value]');
        var lineTotalEl = row.querySelector('[data-line-total]');
        var unitPrice = parseFloat(row.getAttribute('data-unit-price'));

        function updateRowDisplay(newQuantity) {
            row.setAttribute('data-quantity', newQuantity);
            qtyValueEl.textContent = newQuantity;
            lineTotalEl.textContent = formatNumber(unitPrice * newQuantity);

            // افکت کوچک "بامزه" روی عدد تعداد و کل ردیف
            qtyValueEl.classList.remove('bump');
            void qtyValueEl.offsetWidth; // ری‌استارت انیمیشن
            qtyValueEl.classList.add('bump');

            row.classList.remove('row-pulse');
            void row.offsetWidth;
            row.classList.add('row-pulse');
        }

        row.querySelector('[data-qty-increase]').addEventListener('click', function () {
            var newQuantity = parseInt(row.getAttribute('data-quantity'), 10) + 1;
            updateRowDisplay(newQuantity);
            recalculateGrandTotal();
        });

        row.querySelector('[data-qty-decrease]').addEventListener('click', function () {
            var currentQuantity = parseInt(row.getAttribute('data-quantity'), 10);
            var newQuantity = currentQuantity - 1;

            if (newQuantity <= 0) {
                removeRow(row);
                return;
            }

            updateRowDisplay(newQuantity);
            recalculateGrandTotal();
        });
    });

    recalculateGrandTotal();
});
