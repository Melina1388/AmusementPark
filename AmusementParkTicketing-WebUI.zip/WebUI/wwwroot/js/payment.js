// ==========================================================================
// payment.js
// پیش‌نمایش زنده‌ی کارت بانکی، فرمت‌دهی ورودی‌ها، چرخش کارت هنگام فوکوس روی CVV2
// و نمایش یک اسپینر کوتاه قبل از ارسال واقعی فرم به سرور.
// ==========================================================================

document.addEventListener('DOMContentLoaded', function () {

    var cardNumberInput = document.getElementById('cardNumberInput');
    var cardHolderInput = document.getElementById('cardHolderInput');
    var expiryInput = document.getElementById('expiryInput');
    var cvvInput = document.getElementById('cvvInput');

    var previewCardNumber = document.getElementById('previewCardNumber');
    var previewCardHolder = document.getElementById('previewCardHolder');
    var previewExpiry = document.getElementById('previewExpiry');
    var previewCvv = document.getElementById('previewCvv');
    var card3d = document.getElementById('card3d');

    // ---- فرمت‌دهی شماره کارت به‌صورت گروه‌های ۴ رقمی هنگام تایپ ----
    cardNumberInput.addEventListener('input', function () {
        var digitsOnly = cardNumberInput.value.replace(/\D/g, '').slice(0, 16);
        var grouped = digitsOnly.replace(/(.{4})/g, '$1 ').trim();
        cardNumberInput.value = grouped;

        var displayValue = digitsOnly.padEnd(16, '•').replace(/(.{4})/g, '$1 ').trim();
        previewCardNumber.textContent = displayValue;
    });

    // ---- نام دارنده‌ی کارت (به‌صورت بزرگ روی کارت) ----
    cardHolderInput.addEventListener('input', function () {
        previewCardHolder.textContent = cardHolderInput.value.trim() ? cardHolderInput.value.toUpperCase() : 'CARD HOLDER';
    });

    // ---- تاریخ انقضا با درج خودکار "/" ----
    expiryInput.addEventListener('input', function () {
        var digitsOnly = expiryInput.value.replace(/\D/g, '').slice(0, 4);
        if (digitsOnly.length >= 3) {
            expiryInput.value = digitsOnly.slice(0, 2) + '/' + digitsOnly.slice(2);
        } else {
            expiryInput.value = digitsOnly;
        }
        previewExpiry.textContent = expiryInput.value || 'MM/YY';
    });

    // ---- CVV2: هم پشت کارت را پر می‌کند و هم باعث چرخش کارت می‌شود ----
    cvvInput.addEventListener('input', function () {
        var digitsOnly = cvvInput.value.replace(/\D/g, '').slice(0, 4);
        cvvInput.value = digitsOnly;
        previewCvv.textContent = digitsOnly.padEnd(3, '•');
    });

    cvvInput.addEventListener('focus', function () {
        card3d.classList.add('flipped');
    });

    cvvInput.addEventListener('blur', function () {
        card3d.classList.remove('flipped');
    });

    // ---- نمایش اسپینر کوتاه قبل از ارسال واقعی فرم (فقط برای حس تجربه‌ی بهتر) ----
    var paymentForm = document.getElementById('paymentForm');
    var payBtn = document.getElementById('payBtn');

    paymentForm.addEventListener('submit', function (e) {
        if (payBtn.classList.contains('loading')) {
            return; // از ارسال دوباره در حین پردازش جلوگیری می‌کند
        }
        e.preventDefault();
        payBtn.classList.add('loading');

        window.setTimeout(function () {
            paymentForm.submit();
        }, 900);
    });
});
