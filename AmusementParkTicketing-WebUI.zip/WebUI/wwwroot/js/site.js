// ==========================================================================
// site.js
// رفتار سمت کاربر: باز/بسته کردن ساید‌بار، دکمه‌ی بازگشت به بالا،
// نمایان‌سازی تدریجی بخش‌های شهربازی هنگام اسکرول (Scroll Reveal)،
// و تولید تصادفی تکه‌های کنفتی در پس‌زمینه.
// ==========================================================================

document.addEventListener('DOMContentLoaded', function () {

    var menuBtn = document.getElementById('menuBtn');
    var sidebar = document.getElementById('sidebar');
    var overlay = document.getElementById('overlay');
    var backToTopBtn = document.getElementById('backToTop');
    var parkSections = document.querySelectorAll('.park-section');
    var confettiWrap = document.getElementById('confetti');

    /**
     * باز یا بسته کردن ساید‌بار کشویی و هماهنگ کردن وضعیت دکمه‌ی همبرگری و overlay.
     * @param {boolean} shouldOpen
     */
    function toggleSidebar(shouldOpen) {
        menuBtn.classList.toggle('open', shouldOpen);
        sidebar.classList.toggle('show', shouldOpen);
        overlay.classList.toggle('show', shouldOpen);
        menuBtn.setAttribute('aria-expanded', shouldOpen ? 'true' : 'false');
    }

    if (menuBtn && sidebar && overlay) {
        menuBtn.addEventListener('click', function () {
            var isCurrentlyOpen = sidebar.classList.contains('show');
            toggleSidebar(!isCurrentlyOpen);
        });

        overlay.addEventListener('click', function () {
            toggleSidebar(false);
        });
    }

    if (backToTopBtn) {
        backToTopBtn.addEventListener('click', function () {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    // نمایان‌سازی تدریجی هر بخش شهربازی و کارت‌های آن، فقط یک‌بار، هنگام ورود به دید کاربر.
    if ('IntersectionObserver' in window && parkSections.length) {
        var revealObserver = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (entry.isIntersecting) {
                    entry.target.classList.add('revealed');
                    revealObserver.unobserve(entry.target);
                }
            });
        }, { threshold: 0.15 });

        parkSections.forEach(function (section) {
            revealObserver.observe(section);
        });
    } else {
        // مرورگرهای قدیمی‌تر: مستقیماً نمایش داده شود، بدون افکت.
        parkSections.forEach(function (section) {
            section.classList.add('revealed');
        });
    }

    // تولید چند تکه کنفتی سبک برای پس‌زمینه (تعداد کم برای حفظ کارایی صفحه).
    if (confettiWrap) {
        var confettiColors = ['#ff3d7f', '#00d9c0', '#ffc94d', '#9d7bff'];
        for (var i = 0; i < 14; i++) {
            var piece = document.createElement('span');
            piece.style.left = (Math.random() * 100) + '%';
            piece.style.background = confettiColors[i % confettiColors.length];
            piece.style.animationDuration = (7 + Math.random() * 6) + 's';
            piece.style.animationDelay = (Math.random() * 8) + 's';
            confettiWrap.appendChild(piece);
        }
    }
});
