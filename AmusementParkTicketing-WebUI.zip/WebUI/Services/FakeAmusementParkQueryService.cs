using AmusementParkTicketing.WebUI.Models.ViewModels;
using AmusementParkTicketing.WebUI.Services.Abstractions;

namespace AmusementParkTicketing.WebUI.Services
{
    /// <summary>
    /// پیاده‌سازی موقت و درون‌حافظه‌ای (In-Memory) از <see cref="IAmusementParkQueryService"/>.
    ///
    /// این کلاس فقط برای مرحله‌ی فعلی پروژه (پیاده‌سازی UI) وجود دارد تا صفحه‌ی اصلی
    /// بدون نیاز به دیتابیس یا لایه‌ی Application، دادهٔ نمایشی داشته باشد.
    /// وقتی لایه‌های Domain/Application/Infrastructure پیاده‌سازی شدند،
    /// این کلاس باید حذف و به‌جای آن یک Repository واقعی از طریق Infrastructure تزریق شود.
    /// </summary>
    public sealed class FakeAmusementParkQueryService : IAmusementParkQueryService
    {
        // داده‌ی نمونه؛ صرفاً برای نمایش UI. در نسخه‌ی نهایی از دیتابیس خوانده می‌شود.
        private static readonly IReadOnlyCollection<AmusementParkViewModel> SampleAmusementParks = new List<AmusementParkViewModel>
        {
            new AmusementParkViewModel
            {
                Id = 1,
                Name = "شهربازی ارم",
                City = "تهران",
                Rides = new List<RideViewModel>
                {
                    new RideViewModel { Id = 101, Name = "ترن هوایی",   Price = 180000m },
                    new RideViewModel { Id = 102, Name = "چرخ و فلک",   Price = 90000m  },
                    new RideViewModel { Id = 103, Name = "خانه وحشت",   Price = 120000m },
                    new RideViewModel { Id = 104, Name = "قطار مرگ",    Price = 150000m },
                }
            },
            new AmusementParkViewModel
            {
                Id = 2,
                Name = "لوناپارک نور",
                City = "مشهد",
                Rides = new List<RideViewModel>
                {
                    new RideViewModel { Id = 201, Name = "قایق تصادفی",   Price = 100000m },
                    new RideViewModel { Id = 202, Name = "برج سقوط آزاد", Price = 200000m },
                    new RideViewModel { Id = 203, Name = "ماشین برقی",    Price = 80000m  },
                }
            },
            new AmusementParkViewModel
            {
                Id = 3,
                Name = "شهربازی پارک ملت",
                City = "اصفهان",
                Rides = new List<RideViewModel>
                {
                    new RideViewModel { Id = 301, Name = "چرخ فلک غول‌پیکر", Price = 130000m },
                    new RideViewModel { Id = 302, Name = "هشت تصادفی",       Price = 95000m  },
                    new RideViewModel { Id = 303, Name = "سینما ۵ بعدی",     Price = 170000m },
                    new RideViewModel { Id = 304, Name = "تاب زنجیری",       Price = 70000m  },
                }
            }
        };

        /// <inheritdoc/>
        public Task<IReadOnlyCollection<AmusementParkViewModel>> GetAmusementParksAsync(string? searchTerm)
        {
            // اگر عبارت جستجو خالی باشد، کل لیست بازگردانده می‌شود.
            if (string.IsNullOrWhiteSpace(searchTerm))
            {
                return Task.FromResult(SampleAmusementParks);
            }

            // فیلتر کردن بر اساس نام شهربازی (غیرحساس به بزرگی/کوچکی حروف).
            var filteredParks = SampleAmusementParks
                .Where(park => park.Name.Contains(searchTerm, StringComparison.OrdinalIgnoreCase))
                .ToList();

            return Task.FromResult<IReadOnlyCollection<AmusementParkViewModel>>(filteredParks);
        }
    }
}
