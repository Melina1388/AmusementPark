namespace AmusementParkTicketing.WebUI.Services.Abstractions
{
    /// <summary>
    /// رکورد یک سفارش ثبت‌شده. عمداً هیچ‌جا CVV2 نگه‌داری نمی‌شود (حتی در این نسخه‌ی دمو)؛
    /// طبق استاندارد PCI-DSS، CVV2 هرگز نباید بعد از تراکنش ذخیره شود.
    /// شماره کارت هم فقط به‌صورت پوشیده (۴ رقم آخر) ذخیره می‌شود.
    /// </summary>
    public sealed class OrderRecord
    {
        public int Id { get; init; }
        public string MaskedCardNumber { get; init; } = string.Empty;
        public string CardHolderName { get; init; } = string.Empty;
        public decimal TotalAmount { get; init; }
        public DateTime CreatedAtUtc { get; init; }
    }

    /// <summary>
    /// انتزاع ذخیره‌سازی سفارش‌ها. چون درگاه پرداخت واقعی وصل نیست، این فقط برای
    /// «ثبت در دیتابیس خودمان» طبق خواسته‌ی کاربر است. در نسخه‌ی نهایی باید با
    /// یک Repository واقعی (مثلاً روی SQL Server از طریق Infrastructure) جایگزین شود.
    /// </summary>
    public interface IOrderRepository
    {
        Task<OrderRecord> SaveOrderAsync(string maskedCardNumber, string cardHolderName, decimal totalAmount);
    }
}
