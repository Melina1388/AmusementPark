using AmusementParkTicketing.WebUI.Models.ViewModels;

namespace AmusementParkTicketing.WebUI.Services.Abstractions
{
    /// <summary>
    /// انتزاع (Abstraction) واکشی داده‌ی شهربازی‌ها برای نمایش در صفحه‌ی اصلی.
    ///
    /// نکته‌ی مهم معماری Onion / اصل Dependency Inversion (D در SOLID):
    /// Controller به این Interface وابسته است، نه به یک پیاده‌سازی مشخص.
    /// در حال حاضر (چون فقط UI پیاده‌سازی می‌شود) این Interface توسط
    /// «FakeAmusementParkQueryService» با داده‌ی درون‌حافظه‌ای پیاده‌سازی شده است.
    /// در گام بعدی، این Interface باید به پروژه‌ی Application منتقل شود و
    /// پیاده‌سازی واقعی آن (که از طریق Infrastructure به دیتابیس وصل می‌شود)
    /// جایگزین نسخه‌ی فیک شود؛ بدون این‌که حتی یک خط از Controller یا View تغییر کند.
    /// </summary>
    public interface IAmusementParkQueryService
    {
        /// <summary>
        /// لیست شهربازی‌ها را برمی‌گرداند. اگر searchTerm خالی نباشد،
        /// فقط شهربازی‌هایی که نامشان شامل عبارت جستجو باشد بازگردانده می‌شوند.
        /// </summary>
        /// <param name="searchTerm">عبارت جستجوی نام شهربازی (اختیاری).</param>
        Task<IReadOnlyCollection<AmusementParkViewModel>> GetAmusementParksAsync(string? searchTerm);
    }
}
