using AmusementParkTicketing.WebUI.Models.ViewModels;

namespace AmusementParkTicketing.WebUI.Services.Abstractions
{
    /// <summary>
    /// انتزاع خواندن سبد خرید فعلی کاربر.
    /// در حال حاضر (مرحله‌ی UI) با داده‌ی نمونه‌ی ثابت پر می‌شود (<see cref="MockCartService"/>).
    /// در نسخه‌ی نهایی باید با Session یا دیتابیس کار کند تا وقتی کاربر از صفحه‌ی اصلی
    /// روی «افزودن به سبد» می‌زند، همان بلیط واقعاً اینجا ذخیره و بازیابی شود.
    /// </summary>
    public interface ICartService
    {
        Task<CartViewModel> GetCartAsync();
    }
}
