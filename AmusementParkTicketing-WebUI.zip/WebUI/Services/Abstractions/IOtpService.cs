namespace AmusementParkTicketing.WebUI.Services.Abstractions
{
    /// <summary>
    /// انتزاع سرویس ارسال و اعتبارسنجی کد تایید پیامکی (OTP).
    ///
    /// طبق اصل Dependency Inversion، AccountController فقط این Interface را می‌شناسد.
    /// در حال حاضر (مرحله‌ی UI) پیاده‌سازی آن در حافظه (Fake) است.
    /// در نسخه‌ی نهایی، پیاده‌سازی واقعی باید از طریق Infrastructure به یک سرویس
    /// پیامکی واقعی (مثل کاوه‌نگار/ملی‌پیامک) وصل شود؛ بدون نیاز به تغییر در Controller.
    /// </summary>
    public interface IOtpService
    {
        /// <summary>
        /// یک کد تایید ۴ رقمی تولید و برای شماره موبایل داده‌شده ارسال می‌کند.
        /// </summary>
        Task SendVerificationCodeAsync(string mobileNumber);

        /// <summary>
        /// بررسی می‌کند که آیا کد وارد شده برای شماره موبایل داده‌شده معتبر است یا نه.
        /// </summary>
        Task<bool> ValidateCodeAsync(string mobileNumber, string code);
    }
}
