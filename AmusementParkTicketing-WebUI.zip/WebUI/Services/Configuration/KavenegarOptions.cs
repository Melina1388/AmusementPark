namespace AmusementParkTicketing.WebUI.Services.Configuration
{
    /// <summary>
    /// تنظیمات اتصال به سرویس پیامکی کاوه‌نگار.
    /// این کلاس از بخش "Kavenegar" فایل appsettings.json پر می‌شود (الگوی Options در ASP.NET Core).
    /// هرگز مقدار واقعی ApiKey را داخل کد یا appsettings.json عمومی قرار ندهید؛
    /// برای محیط Production از User Secrets یا متغیرهای محیطی (Environment Variables) استفاده کنید.
    /// </summary>
    public sealed class KavenegarOptions
    {
        /// <summary>کلید API که از پنل کاوه‌نگار (بخش تنظیمات حساب) دریافت می‌کنید.</summary>
        public string ApiKey { get; set; } = string.Empty;

        /// <summary>
        /// نام الگوی (Template) از پیش تعریف‌شده در پنل کاوه‌نگار برای ارسال کد تایید.
        /// باید دقیقاً همان اسمی باشد که در پنل ساخته‌اید (مثلاً "otp-code").
        /// </summary>
        public string VerifyTemplate { get; set; } = "otp-code";
    }
}
