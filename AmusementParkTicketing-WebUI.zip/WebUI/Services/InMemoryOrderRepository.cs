using System.Collections.Concurrent;
using AmusementParkTicketing.WebUI.Services.Abstractions;

namespace AmusementParkTicketing.WebUI.Services
{
    /// <summary>
    /// پیاده‌سازی موقت و درون‌حافظه‌ای <see cref="IOrderRepository"/>.
    /// سفارش‌ها فقط تا زمانی که برنامه در حال اجراست نگه‌داری می‌شوند و با ری‌استارت از بین می‌روند.
    /// وقتی Infrastructure واقعی (مثلاً Entity Framework Core) اضافه شد، این کلاس باید حذف شود.
    /// </summary>
    public sealed class InMemoryOrderRepository : IOrderRepository
    {
        private static readonly ConcurrentBag<OrderRecord> Orders = new();
        private static int _nextId = 1;

        public Task<OrderRecord> SaveOrderAsync(string maskedCardNumber, string cardHolderName, decimal totalAmount)
        {
            var order = new OrderRecord
            {
                Id = Interlocked.Increment(ref _nextId),
                MaskedCardNumber = maskedCardNumber,
                CardHolderName = cardHolderName,
                TotalAmount = totalAmount,
                CreatedAtUtc = DateTime.UtcNow
            };

            Orders.Add(order);
            return Task.FromResult(order);
        }
    }
}
