using System.Collections.Concurrent;
using AmusementParkTicketing.WebUI.Services.Abstractions;

namespace AmusementParkTicketing.WebUI.Services
{
    /// <summary>
    /// پیاده‌سازی موقت و درون‌حافظه‌ای <see cref="IOtpService"/>.
    /// هیچ پیامک واقعی ارسال نمی‌شود؛ کد تولیدشده فقط در حافظه نگه‌داری می‌شود
    /// تا بتوان جریان UI (ورود → تایید کد) را بدون اتصال به سرویس پیامکی واقعی تست کرد.
    /// وقتی Infrastructure واقعی اضافه شد، این کلاس باید حذف شود.
    /// </summary>
    public sealed class FakeOtpService : IOtpService
    {
        // نگه‌داری آخرین کد ارسال‌شده برای هر شماره موبایل (فقط برای محیط توسعه/دمو).
        private static readonly ConcurrentDictionary<string, string> LastSentCodes = new();

        // در محیط دمو، این کد همیشه معتبر شناخته می‌شود تا تست UI بدون نیاز به دیدن لاگ راحت‌تر باشد.
        private const string DemoBypassCode = "1234";

        /// <inheritdoc/>
        public Task SendVerificationCodeAsync(string mobileNumber)
        {
            var generatedCode = Random.Shared.Next(1000, 9999).ToString();
            LastSentCodes[mobileNumber] = generatedCode;

            // TODO: در نسخه‌ی نهایی، اینجا باید از طریق Infrastructure به یک سرویس پیامکی واقعی وصل شود.
            System.Diagnostics.Debug.WriteLine($"[FakeOtpService] کد ارسال‌شده به {mobileNumber}: {generatedCode}");

            return Task.CompletedTask;
        }

        /// <inheritdoc/>
        public Task<bool> ValidateCodeAsync(string mobileNumber, string code)
        {
            var isDemoBypass = code == DemoBypassCode;
            var isMatchingGeneratedCode = LastSentCodes.TryGetValue(mobileNumber, out var sentCode) && sentCode == code;

            return Task.FromResult(isDemoBypass || isMatchingGeneratedCode);
        }
    }
}
