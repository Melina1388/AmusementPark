using System.Collections.Concurrent;
using System.Net;
using AmusementParkTicketing.WebUI.Services.Abstractions;
using AmusementParkTicketing.WebUI.Services.Configuration;
using Microsoft.Extensions.Options;

namespace AmusementParkTicketing.WebUI.Services
{
    /// <summary>
    /// پیاده‌سازی واقعی <see cref="IOtpService"/> با استفاده از سرویس پیامکی کاوه‌نگار
    /// (متد Verify Lookup که مخصوص ارسال کدهای تایید طراحی شده است).
    ///
    /// نکته‌ی مهم: کاوه‌نگار endpoint ای برای "بررسی صحت کد" ارائه نمی‌دهد؛ این برنامه خودش
    /// کد را تولید می‌کند، آن را (فقط در حافظه‌ی سرور) نگه می‌دارد، از طریق کاوه‌نگار پیامک می‌کند،
    /// و در ValidateCodeAsync آن را با ورودی کاربر مقایسه می‌کند.
    ///
    /// طبق معماری Onion، این کلاس در نهایت باید به پروژه‌ی Infrastructure منتقل شود
    /// (چون به یک سرویس خارجی وابسته است)؛ چیزی که در سطح Controller/View تغییری ایجاد نمی‌کند
    /// چون همه‌چیز پشت IOtpService پنهان است.
    /// </summary>
    public sealed class KavenegarOtpService : IOtpService
    {
        private readonly HttpClient _httpClient;
        private readonly KavenegarOptions _options;

        // نگه‌داری موقت کدهای ارسال‌شده به همراه زمان انقضا (۲ دقیقه).
        // در نسخه‌ی نهایی بهتر است این‌ها را در Redis/Distributed Cache نگه دارید
        // تا بین چند نمونه (Instance) از برنامه هم به‌درستی کار کند.
        private static readonly ConcurrentDictionary<string, (string Code, DateTime ExpiresAtUtc)> PendingCodes = new();

        public KavenegarOtpService(HttpClient httpClient, IOptions<KavenegarOptions> options)
        {
            _httpClient = httpClient ?? throw new ArgumentNullException(nameof(httpClient));
            _options = options?.Value ?? throw new ArgumentNullException(nameof(options));
        }

        /// <inheritdoc/>
        public async Task SendVerificationCodeAsync(string mobileNumber)
        {
            var generatedCode = Random.Shared.Next(1000, 9999).ToString();
            PendingCodes[mobileNumber] = (generatedCode, DateTime.UtcNow.AddMinutes(2));

            // ساخت آدرس درخواست طبق مستندات Verify Lookup کاوه‌نگار:
            // https://api.kavenegar.com/v1/{ApiKey}/verify/lookup.json?receptor=...&token=...&template=...
            var requestUrl =
                $"https://api.kavenegar.com/v1/{Uri.EscapeDataString(_options.ApiKey)}/verify/lookup.json" +
                $"?receptor={Uri.EscapeDataString(mobileNumber)}" +
                $"&token={Uri.EscapeDataString(generatedCode)}" +
                $"&template={Uri.EscapeDataString(_options.VerifyTemplate)}";

            using var response = await _httpClient.GetAsync(requestUrl);

            if (response.StatusCode == HttpStatusCode.Unauthorized)
            {
                throw new InvalidOperationException(
                    "درخواست پیامک رد شد: API Key کاوه‌نگار نامعتبر است یا هنوز در appsettings.json تنظیم نشده.");
            }

            if (!response.IsSuccessStatusCode)
            {
                var errorBody = await response.Content.ReadAsStringAsync();
                throw new InvalidOperationException($"ارسال پیامک با خطا مواجه شد: {response.StatusCode} - {errorBody}");
            }

            // پاسخ کاوه‌نگار را می‌توان در صورت نیاز برای لاگ کردن messageid و وضعیت تجزیه کرد.
            // var responseBody = await response.Content.ReadAsStringAsync();
            // var parsed = JsonSerializer.Deserialize<JsonElement>(responseBody);
        }

        /// <inheritdoc/>
        public Task<bool> ValidateCodeAsync(string mobileNumber, string code)
        {
            if (!PendingCodes.TryGetValue(mobileNumber, out var entry))
            {
                return Task.FromResult(false);
            }

            var isExpired = entry.ExpiresAtUtc < DateTime.UtcNow;
            var isMatch = !isExpired && entry.Code == code;

            if (isMatch)
            {
                // کد پس از یک بار استفاده‌ی موفق باطل می‌شود.
                PendingCodes.TryRemove(mobileNumber, out _);
            }

            return Task.FromResult(isMatch);
        }
    }
}
