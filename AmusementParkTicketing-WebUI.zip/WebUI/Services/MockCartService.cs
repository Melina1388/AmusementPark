using AmusementParkTicketing.WebUI.Models.ViewModels;
using AmusementParkTicketing.WebUI.Services.Abstractions;

namespace AmusementParkTicketing.WebUI.Services
{
    /// <summary>
    /// پیاده‌سازی موقت <see cref="ICartService"/> که یک سبد خرید نمونه (شامل بلیط از دو
    /// شهربازی مختلف) برمی‌گرداند؛ دقیقاً برای نمایش سناریوی گروه‌بندی بر اساس شهربازی.
    /// این کلاس باید در نسخه‌ی نهایی با یک سرویس واقعی (متصل به Session/دیتابیس) جایگزین شود.
    /// </summary>
    public sealed class MockCartService : ICartService
    {
        public Task<CartViewModel> GetCartAsync()
        {
            var cart = new CartViewModel
            {
                ParkGroups = new List<CartParkGroupViewModel>
                {
                    new CartParkGroupViewModel
                    {
                        ParkName = "شهربازی ارم",
                        Items = new List<CartItemViewModel>
                        {
                            new CartItemViewModel { RideId = 101, RideName = "ترن هوایی", UnitPrice = 180000m, Quantity = 2 },
                            new CartItemViewModel { RideId = 102, RideName = "چرخ و فلک", UnitPrice = 90000m,  Quantity = 1 },
                        }
                    },
                    new CartParkGroupViewModel
                    {
                        ParkName = "شهربازی بسیج",
                        Items = new List<CartItemViewModel>
                        {
                            new CartItemViewModel { RideId = 401, RideName = "قطار وحشت", UnitPrice = 140000m, Quantity = 3 },
                        }
                    }
                }
            };

            return Task.FromResult(cart);
        }
    }
}
