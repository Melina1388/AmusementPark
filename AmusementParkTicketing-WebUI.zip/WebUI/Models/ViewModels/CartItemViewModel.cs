namespace AmusementParkTicketing.WebUI.Models.ViewModels
{
    /// <summary>
    /// یک ردیف داخل سبد خرید: یک نوع بازی، به همراه تعداد بلیط انتخابی و قیمت واحد.
    /// </summary>
    public sealed class CartItemViewModel
    {
        public int RideId { get; init; }
        public string RideName { get; init; } = string.Empty;
        public decimal UnitPrice { get; init; }
        public int Quantity { get; init; }

        /// <summary>قیمت این ردیف (قیمت واحد ضربدر تعداد).</summary>
        public decimal LineTotal => UnitPrice * Quantity;
    }
}
