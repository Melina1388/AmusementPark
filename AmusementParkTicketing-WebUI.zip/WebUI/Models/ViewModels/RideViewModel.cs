namespace AmusementParkTicketing.WebUI.Models.ViewModels
{
    /// <summary>
    /// مدل نمایشی یک بازی/وسیله‌ی تفریحی داخل یک شهربازی.
    /// این کلاس فقط برای نمایش در View استفاده می‌شود و نباید منطق دامنه (Domain) داشته باشد؛
    /// طبق اصل Single Responsibility، مسئولیت آن فقط "حمل داده برای UI" است.
    /// در آینده، داده‌ی واقعی این مدل از طریق لایه‌ی Application (با Mapping از Entity دامنه) پر خواهد شد.
    /// </summary>
    public sealed class RideViewModel
    {
        /// <summary>شناسه‌ی یکتای بازی (برای لینک به صفحه‌ی جزئیات یا خرید بلیط).</summary>
        public int Id { get; init; }

        /// <summary>نام بازی/وسیله (مثلاً «ترن هوایی»).</summary>
        public string Name { get; init; } = string.Empty;

        /// <summary>آدرس تصویر شاخص بازی. مقدار پیش‌فرض خالی یعنی از تصویر placeholder استفاده شود.</summary>
        public string ImageUrl { get; init; } = string.Empty;

        /// <summary>قیمت بلیط این بازی به تومان.</summary>
        public decimal Price { get; init; }
    }
}
