namespace AmusementParkTicketing.WebUI.Models.ViewModels
{
    /// <summary>
    /// مدل نمایشی کامل صفحه‌ی اصلی (Home/Index).
    /// این کلاس، مدل ریشه‌ای (Root ViewModel) صفحه است و View فقط با همین یک شیء کار می‌کند؛
    /// این کار باعث می‌شود View هیچ وابستگی مستقیمی به لایه‌های داخلی‌تر (Application/Domain) نداشته باشد
    /// و اصل Dependency Inversion در معماری Onion رعایت شود.
    /// </summary>
    public sealed class HomePageViewModel
    {
        /// <summary>عبارت جستجوی فعلی کاربر (برای نگه‌داشتن مقدار داخل input هنگام postback در آینده).</summary>
        public string? SearchTerm { get; init; }

        /// <summary>لیست شهربازی‌هایی که باید در صفحه‌ی اصلی نمایش داده شوند.</summary>
        public IReadOnlyCollection<AmusementParkViewModel> AmusementParks { get; init; } = Array.Empty<AmusementParkViewModel>();
    }
}
