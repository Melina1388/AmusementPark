using System.ComponentModel.DataAnnotations;

namespace AmusementParkTicketing.WebUI.Models.ViewModels
{
    /// <summary>
    /// مدل نمایشی فرم پرداخت.
    /// این پروژه به درگاه پرداخت واقعی وصل نیست؛ این فرم فقط UI پرداخت را شبیه‌سازی می‌کند
    /// و در نهایت فقط یک رکورد سفارش (بدون CVV2) در «دیتابیس» داخلی (فعلاً حافظه) ثبت می‌شود.
    /// </summary>
    public sealed class PaymentViewModel
    {
        [Required(ErrorMessage = "شماره کارت را وارد کنید.")]
        [RegularExpression(@"^\d{16}$", ErrorMessage = "شماره کارت باید ۱۶ رقم باشد.")]
        [Display(Name = "شماره کارت")]
        public string CardNumber { get; set; } = string.Empty;

        [Required(ErrorMessage = "نام دارنده‌ی کارت را وارد کنید.")]
        [Display(Name = "نام دارنده‌ی کارت")]
        public string CardHolderName { get; set; } = string.Empty;

        [Required(ErrorMessage = "تاریخ انقضا را وارد کنید.")]
        [RegularExpression(@"^(0[1-9]|1[0-2])\/\d{2}$", ErrorMessage = "قالب تاریخ انقضا باید MM/YY باشد.")]
        [Display(Name = "تاریخ انقضا")]
        public string ExpiryDate { get; set; } = string.Empty;

        [Required(ErrorMessage = "CVV2 را وارد کنید.")]
        [RegularExpression(@"^\d{3,4}$", ErrorMessage = "CVV2 باید ۳ یا ۴ رقم باشد.")]
        [Display(Name = "CVV2")]
        public string Cvv2 { get; set; } = string.Empty;

        /// <summary>مبلغ نهایی قابل پرداخت (از صفحه‌ی سبد خرید منتقل می‌شود).</summary>
        [Required]
        public decimal TotalAmount { get; set; }
    }
}
