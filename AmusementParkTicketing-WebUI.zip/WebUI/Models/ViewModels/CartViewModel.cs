namespace AmusementParkTicketing.WebUI.Models.ViewModels
{
    /// <summary>
    /// گروهی از ردیف‌های سبد خرید که همگی متعلق به یک شهربازی هستند.
    /// در View، نام شهربازی فقط یک‌بار بالای این گروه نمایش داده می‌شود.
    /// </summary>
    public sealed class CartParkGroupViewModel
    {
        public string ParkName { get; init; } = string.Empty;
        public IReadOnlyCollection<CartItemViewModel> Items { get; init; } = Array.Empty<CartItemViewModel>();

        /// <summary>جمع قیمت تمام بلیط‌های این شهربازی.</summary>
        public decimal ParkTotal => Items.Sum(item => item.LineTotal);
    }

    /// <summary>
    /// مدل ریشه‌ای صفحه‌ی سبد خرید: لیست گروه‌های شهربازی به همراه جمع کل.
    /// </summary>
    public sealed class CartViewModel
    {
        public IReadOnlyCollection<CartParkGroupViewModel> ParkGroups { get; init; } = Array.Empty<CartParkGroupViewModel>();

        /// <summary>جمع کل قیمت تمام بلیط‌های داخل سبد خرید.</summary>
        public decimal GrandTotal => ParkGroups.Sum(group => group.ParkTotal);

        public bool IsEmpty => ParkGroups.Count == 0;
    }
}
