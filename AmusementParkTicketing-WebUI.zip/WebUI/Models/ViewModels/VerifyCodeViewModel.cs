using System.ComponentModel.DataAnnotations;

namespace AmusementParkTicketing.WebUI.Models.ViewModels
{
    /// <summary>
    /// مدل نمایشی صفحه‌ی تایید کد پیامکی (OTP).
    /// شماره موبایل به‌صورت مخفی (Hidden Field) از صفحه‌ی قبلی به این صفحه منتقل می‌شود
    /// تا کنترلر بداند کد وارد شده باید برای کدام شماره اعتبارسنجی شود.
    /// </summary>
    public sealed class VerifyCodeViewModel
    {
        [Required]
        public string MobileNumber { get; set; } = string.Empty;

        [Required(ErrorMessage = "وارد کردن کد تایید الزامی است.")]
        [RegularExpression(@"^\d{4}$", ErrorMessage = "کد تایید باید ۴ رقم باشد.")]
        [Display(Name = "کد تایید")]
        public string Code { get; set; } = string.Empty;
    }
}
