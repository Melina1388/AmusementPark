using System.ComponentModel.DataAnnotations;

namespace AmusementParkTicketing.WebUI.Models.ViewModels
{
    /// <summary>
    /// مدل نمایشی فرم ورود: دریافت نام کاربری و شماره موبایل از کاربر.
    /// اعتبارسنجی‌ها با Data Annotations انجام می‌شود تا هم در سمت سرور و هم
    /// (در صورت افزودن jQuery Validation) در سمت کاربر به‌صورت خودکار اعمال شود.
    /// </summary>
    public sealed class LoginViewModel
    {
        [Required(ErrorMessage = "وارد کردن نام کاربری الزامی است.")]
        [Display(Name = "نام کاربری")]
        public string Username { get; set; } = string.Empty;

        [Required(ErrorMessage = "وارد کردن شماره موبایل الزامی است.")]
        [RegularExpression(@"^09\d{9}$", ErrorMessage = "شماره موبایل باید ۱۱ رقم و با ۰۹ شروع شود.")]
        [Display(Name = "شماره موبایل")]
        public string MobileNumber { get; set; } = string.Empty;
    }
}
