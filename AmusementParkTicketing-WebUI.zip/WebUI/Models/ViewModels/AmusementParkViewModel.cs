namespace AmusementParkTicketing.WebUI.Models.ViewModels
{
    /// <summary>
    /// مدل نمایشی یک شهربازی به همراه لیست بازی‌های آن.
    /// هر بخش (Section) در صفحه‌ی اصلی از روی یک نمونه از همین کلاس رندر می‌شود.
    /// </summary>
    public sealed class AmusementParkViewModel
    {
        /// <summary>شناسه‌ی یکتای شهربازی.</summary>
        public int Id { get; init; }

        /// <summary>نام شهربازی (مثلاً «شهربازی ارم»). به‌عنوان سرتیتر بخش نمایش داده می‌شود.</summary>
        public string Name { get; init; } = string.Empty;

        /// <summary>نام شهر محل استقرار شهربازی.</summary>
        public string City { get; init; } = string.Empty;

        /// <summary>لیست بازی‌های این شهربازی که به‌صورت افقی (اسکرول) نمایش داده می‌شوند.</summary>
        public IReadOnlyCollection<RideViewModel> Rides { get; init; } = Array.Empty<RideViewModel>();
    }
}
