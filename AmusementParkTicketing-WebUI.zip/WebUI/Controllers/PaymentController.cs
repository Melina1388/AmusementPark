using AmusementParkTicketing.WebUI.Models.ViewModels;
using AmusementParkTicketing.WebUI.Services.Abstractions;
using Microsoft.AspNetCore.Mvc;

namespace AmusementParkTicketing.WebUI.Controllers
{
    /// <summary>
    /// کنترلر صفحه‌ی پرداخت. چون درگاه پرداخت واقعی متصل نیست، این کنترلر فقط
    /// فرم پرداخت را نمایش می‌دهد و در صورت معتبر بودن اطلاعات، یک سفارش «موفق»
    /// در دیتابیس داخلی (فعلاً درون‌حافظه) ثبت می‌کند.
    /// </summary>
    public sealed class PaymentController : Controller
    {
        private readonly IOrderRepository _orderRepository;

        public PaymentController(IOrderRepository orderRepository)
        {
            _orderRepository = orderRepository ?? throw new ArgumentNullException(nameof(orderRepository));
        }

        /// <summary>نمایش فرم پرداخت برای مبلغ داده‌شده (که از صفحه‌ی سبد خرید می‌آید).</summary>
        [HttpGet]
        public IActionResult Index(decimal totalAmount)
        {
            return View(new PaymentViewModel { TotalAmount = totalAmount });
        }

        /// <summary>
        /// پردازش فرم پرداخت: اعتبارسنجی، ماسک کردن شماره کارت، و ثبت سفارش.
        /// CVV2 هرگز ذخیره نمی‌شود (نه در دیتابیس، نه در لاگ) — طبق استاندارد PCI-DSS.
        /// </summary>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Checkout(PaymentViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(nameof(Index), model);
            }

            var maskedCardNumber = "•••• •••• •••• " + model.CardNumber[^4..];

            var savedOrder = await _orderRepository.SaveOrderAsync(
                maskedCardNumber,
                model.CardHolderName,
                model.TotalAmount);

            return View("Success", savedOrder);
        }
    }
}
