using AmusementParkTicketing.WebUI.Services.Abstractions;
using Microsoft.AspNetCore.Mvc;

namespace AmusementParkTicketing.WebUI.Controllers
{
    /// <summary>
    /// کنترلر صفحه‌ی سبد خرید.
    /// طبق اصل Single Responsibility فقط مسئول نمایش سبد است؛ منطق نگه‌داری/محاسبه‌ی سبد
    /// در ICartService و ViewModel های آن قرار دارد.
    /// </summary>
    public sealed class CartController : Controller
    {
        private readonly ICartService _cartService;

        public CartController(ICartService cartService)
        {
            _cartService = cartService ?? throw new ArgumentNullException(nameof(cartService));
        }

        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var cart = await _cartService.GetCartAsync();
            return View(cart);
        }
    }
}
