using AmusementParkTicketing.WebUI.Models.ViewModels;
using AmusementParkTicketing.WebUI.Services.Abstractions;
using Microsoft.AspNetCore.Mvc;

namespace AmusementParkTicketing.WebUI.Controllers
{
    /// <summary>
    /// کنترلر مربوط به احراز هویت: نمایش فرم ورود (نام کاربری + موبایل) و
    /// سپس فرم تایید کد ۴ رقمی که برای موبایل کاربر پیامک می‌شود.
    /// طبق اصل Single Responsibility، این کنترلر فقط جریان صفحات را مدیریت می‌کند؛
    /// تولید/ارسال/اعتبارسنجی کد به IOtpService واگذار شده (Dependency Inversion).
    /// </summary>
    public sealed class AccountController : Controller
    {
        private readonly IOtpService _otpService;

        public AccountController(IOtpService otpService)
        {
            _otpService = otpService ?? throw new ArgumentNullException(nameof(otpService));
        }

        /// <summary>نمایش فرم ورود (گام اول).</summary>
        [HttpGet]
        public IActionResult Login()
        {
            return View(new LoginViewModel());
        }

        /// <summary>
        /// پردازش فرم ورود: در صورت معتبر بودن اطلاعات، کد تایید ارسال شده
        /// و کاربر به صفحه‌ی تایید کد (گام دوم) هدایت می‌شود.
        /// </summary>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            await _otpService.SendVerificationCodeAsync(model.MobileNumber);

            // انتقال به صفحه‌ی جدید (گام دوم) به همراه شماره موبایل برای ادامه‌ی فرآیند.
            return RedirectToAction(nameof(VerifyCode), new { mobileNumber = model.MobileNumber });
        }

        /// <summary>نمایش فرم تایید کد ۴ رقمی (گام دوم).</summary>
        [HttpGet]
        public IActionResult VerifyCode(string mobileNumber)
        {
            if (string.IsNullOrWhiteSpace(mobileNumber))
            {
                // اگر مستقیماً و بدون طی کردن گام اول به این صفحه بیاید، به فرم ورود بازگردانده می‌شود.
                return RedirectToAction(nameof(Login));
            }

            return View(new VerifyCodeViewModel { MobileNumber = mobileNumber });
        }

        /// <summary>پردازش کد تایید وارد شده توسط کاربر.</summary>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> VerifyCode(VerifyCodeViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var isCodeValid = await _otpService.ValidateCodeAsync(model.MobileNumber, model.Code);
            if (!isCodeValid)
            {
                ModelState.AddModelError(nameof(model.Code), "کد وارد شده صحیح نیست یا منقضی شده است.");
                return View(model);
            }

            // TODO: در نسخه‌ی نهایی، اینجا Session/Cookie کاربر ساخته می‌شود (لایه‌ی Application/Infrastructure).
            return RedirectToAction("Index", "Home");
        }
        /// <summary>ارسال مجدد کد تایید برای همان شماره موبایل.</summary>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ResendCode(string mobileNumber)
        {
            if (!string.IsNullOrWhiteSpace(mobileNumber))
            {
                await _otpService.SendVerificationCodeAsync(mobileNumber);
            }

            return RedirectToAction(nameof(VerifyCode), new { mobileNumber });
        }
    }
}
