using AmusementParkTicketing.WebUI.Models.ViewModels;
using AmusementParkTicketing.WebUI.Services.Abstractions;
using Microsoft.AspNetCore.Mvc;

namespace AmusementParkTicketing.WebUI.Controllers
{
    /// <summary>
    /// کنترلر صفحه‌ی اصلی سایت.
    /// طبق اصل Single Responsibility، این کنترلر فقط مسئول «هماهنگی بین درخواست HTTP و View» است
    /// و هیچ منطق واکشی/فیلتر دیتا در خودش ندارد؛ آن منطق در IAmusementParkQueryService قرار دارد.
    /// طبق اصل Dependency Inversion، کنترلر به Interface وابسته است نه به پیاده‌سازی مشخص،
    /// بنابراین جایگزین کردن FakeAmusementParkQueryService با سرویس واقعی در آینده هیچ تغییری
    /// در این کلاس نیاز ندارد.
    /// </summary>
    public sealed class HomeController : Controller
    {
        private readonly IAmusementParkQueryService _amusementParkQueryService;

        /// <summary>
        /// تزریق وابستگی (Dependency Injection) از طریق سازنده‌ی کلاس.
        /// </summary>
        public HomeController(IAmusementParkQueryService amusementParkQueryService)
        {
            _amusementParkQueryService = amusementParkQueryService
                ?? throw new ArgumentNullException(nameof(amusementParkQueryService));
        }

        /// <summary>
        /// نمایش صفحه‌ی اصلی سایت شامل لیست شهربازی‌ها و بازی‌های هرکدام.
        /// </summary>
        /// <param name="searchTerm">عبارت جستجوی نام شهربازی که کاربر وارد کرده (اختیاری).</param>
        [HttpGet]
        public async Task<IActionResult> Index(string? searchTerm)
        {
            var amusementParks = await _amusementParkQueryService.GetAmusementParksAsync(searchTerm);

            var viewModel = new HomePageViewModel
            {
                SearchTerm = searchTerm,
                AmusementParks = amusementParks
            };

            return View(viewModel);
        }
    }
}
