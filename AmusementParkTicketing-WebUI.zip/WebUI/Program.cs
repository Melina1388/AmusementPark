using AmusementParkTicketing.WebUI.Services;
using AmusementParkTicketing.WebUI.Services.Abstractions;
using AmusementParkTicketing.WebUI.Services.Configuration;

var builder = WebApplication.CreateBuilder(args);

// ثبت سرویس‌های MVC (Controllers + Views)
builder.Services.AddControllersWithViews();

// ثبت وابستگی طبق اصل Dependency Inversion:
// در حال حاضر نسخه‌ی فیک (In-Memory) ثبت می‌شود.
// در آینده وقتی لایه‌ی Application/Infrastructure اضافه شد،
// فقط همین یک خط باید به سرویس واقعی تغییر کند؛
// هیچ تغییری در Controller یا View لازم نیست.
builder.Services.AddScoped<IAmusementParkQueryService, FakeAmusementParkQueryService>();
builder.Services.AddScoped<ICartService, MockCartService>();
builder.Services.AddSingleton<IOrderRepository, InMemoryOrderRepository>();

// انتخاب پیاده‌سازی IOtpService بر اساس اینکه API Key کاوه‌نگار تنظیم شده یا نه:
// - اگر appsettings.json مقدار Kavenegar:ApiKey را داشته باشد، پیامک واقعی ارسال می‌شود.
// - در غیر این صورت (مثلاً هنگام توسعه‌ی محلی بدون اکانت پیامکی)، از نسخه‌ی fake استفاده می‌شود
//   که کد را فقط در حافظه نگه می‌دارد (و کد "1234" همیشه معتبر شناخته می‌شود).
var kavenegarApiKey = builder.Configuration["Kavenegar:ApiKey"];
if (!string.IsNullOrWhiteSpace(kavenegarApiKey))
{
    builder.Services.Configure<KavenegarOptions>(builder.Configuration.GetSection("Kavenegar"));
    builder.Services.AddHttpClient<IOtpService, KavenegarOtpService>();
}
else
{
    builder.Services.AddScoped<IOtpService, FakeOtpService>();
}

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles(); // برای سرو کردن فایل‌های wwwroot/css و wwwroot/js
app.UseRouting();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
